create database carros;
use carros;

create table cadastro:
nome varchar(255),
placa varchar(255),
modelo varchar(255),
cpf varchar(255) primary-key;